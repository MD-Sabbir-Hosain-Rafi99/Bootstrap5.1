/* =====================================================
   ABOUT PAGE JAVASCRIPT
===================================================== */


/* =====================================================
   CURRENT DATE & TIME
===================================================== */

function updateDateTime() {

    const now = new Date();


    /* Current Date */

    const dateOptions = {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric"
    };


    const currentDate = now.toLocaleDateString(
        "en-BD",
        dateOptions
    );


    /* Current Time */

    const currentTime = now.toLocaleTimeString(
        "en-BD",
        {
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit"
        }
    );


    /* Show Date */

    const dateElement =
        document.getElementById("currentDate");


    if (dateElement) {

        dateElement.innerText = currentDate;

    }


    /* Show Time */

    const timeElement =
        document.getElementById("currentTime");


    if (timeElement) {

        timeElement.innerText = currentTime;

    }

}


/* Run Function */

updateDateTime();


/* Update Every 1 Second */

setInterval(updateDateTime, 1000);


/* =====================================================
   STAFF CARD HOVER
===================================================== */

$(document).ready(function () {

    $(".staff-card").hover(

        function () {

            $(this).find(".staff-social").stop().fadeIn(200);

        },

        function () {

            $(this).find(".staff-social").stop().fadeIn(200);

        }

    );

});








// ================= DATE & TIME =================

function updateDateTime() {

    const now = new Date();

    const dateOptions = {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric"
    };

    const currentDate = now.toLocaleDateString("en-BD", dateOptions);

    const currentTime = now.toLocaleTimeString("en-BD", {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
    });


    const dateElement = document.getElementById("currentDate");

    if (dateElement) {
        dateElement.innerText = currentDate;
    }


    const timeElement = document.getElementById("currentTime");

    if (timeElement) {
        timeElement.innerText = currentTime;
    }
}


updateDateTime();

setInterval(updateDateTime, 1000);


// ================= JQUERY =================

$(document).ready(function () {

    // Category card hover effect
    $(".category-card").hover(
        function () {
            $(this).css("cursor", "pointer");
        },
        function () {
            $(this).css("cursor", "default");
        }
    );


    // Advertisement button
    $(".advertisement-box button").click(function () {

        alert("বিজ্ঞাপনের জন্য আমাদের সাথে যোগাযোগ করুন।");

    });


    // Pagination click
    $(".pagination .page-link").click(function (e) {

        e.preventDefault();

        $(".pagination .page-item").removeClass("active");

        $(this).parent().addClass("active");

    });

});









// ================= DATE & TIME =================

function updateDateTime() {

    const now = new Date();

    const dateOptions = {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric"
    };

    const currentDate = now.toLocaleDateString(
        "en-BD",
        dateOptions
    );

    const currentTime = now.toLocaleTimeString(
        "en-BD",
        {
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit"
        }
    );


    const dateElement =
        document.getElementById("currentDate");

    if (dateElement) {
        dateElement.innerText = currentDate;
    }


    const timeElement =
        document.getElementById("currentTime");

    if (timeElement) {
        timeElement.innerText = currentTime;
    }

}


// Run immediately
updateDateTime();


// Update every second
setInterval(updateDateTime, 1000);


// ================= JQUERY =================

$(document).ready(function () {


    // Author card hover effect

    $(".author-card").hover(

        function () {

            $(this)
                .find(".author-social")
                .stop(true, true)
                .fadeIn(200);

        },

        function () {

            $(this)
                .find(".author-social")
                .stop(true, true)
                .fadeIn(200);

        }

    );


    // Social icon click

    $(".author-social a").click(function (e) {

        e.preventDefault();

    });

});







// ================= DATE & TIME =================

function updateDateTime() {

    const now = new Date();

    const dateOptions = {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric"
    };

    const currentDate = now.toLocaleDateString(
        "en-BD",
        dateOptions
    );

    const currentTime = now.toLocaleTimeString(
        "en-BD",
        {
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit"
        }
    );


    const dateElement =
        document.getElementById("currentDate");

    if (dateElement) {
        dateElement.innerText = currentDate;
    }


    const timeElement =
        document.getElementById("currentTime");

    if (timeElement) {
        timeElement.innerText = currentTime;
    }

}


updateDateTime();

setInterval(updateDateTime, 1000);


// ================= CONTACT FORM =================

$(document).ready(function () {

    $("#contactForm").submit(function (e) {

        e.preventDefault();


        // Clear previous errors

        $(".error-message").text("");

        $(".form-control").removeClass("is-invalid");


        let name = $("#name").val().trim();
        let email = $("#email").val().trim();
        let mobile = $("#mobile").val().trim();
        let message = $("#message").val().trim();

        let isValid = true;


        // ================= NAME =================

        if (name === "") {

            $("#nameError").text("Please enter your name.");

            $("#name").addClass("is-invalid");

            isValid = false;

        }


        // ================= EMAIL =================

        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


        if (email === "") {

            $("#emailError").text("Please enter your email.");

            $("#email").addClass("is-invalid");

            isValid = false;

        }

        else if (!emailPattern.test(email)) {

            $("#emailError").text("Please enter a valid email.");

            $("#email").addClass("is-invalid");

            isValid = false;

        }


        // ================= MOBILE =================

        const mobilePattern =
            /^[0-9+\-\s]{10,15}$/;


        if (mobile === "") {

            $("#mobileError").text("Please enter your mobile number.");

            $("#mobile").addClass("is-invalid");

            isValid = false;

        }

        else if (!mobilePattern.test(mobile)) {

            $("#mobileError").text("Please enter a valid mobile number.");

            $("#mobile").addClass("is-invalid");

            isValid = false;

        }


        // ================= MESSAGE =================

        if (message === "") {

            $("#messageError").text("Please write your message.");

            $("#message").addClass("is-invalid");

            isValid = false;

        }

        else if (message.length < 10) {

            $("#messageError").text(
                "Message must contain at least 10 characters."
            );

            $("#message").addClass("is-invalid");

            isValid = false;

        }


        // ================= SUCCESS =================

        if (isValid) {

            alert(
                "Thank you, " +
                name +
                "! Your message has been sent successfully."
            );

            $("#contactForm")[0].reset();

            $(".form-control").removeClass("is-valid");

        }

    });


    // Remove error when user starts typing

    $(".form-control").on("input", function () {

        $(this).removeClass("is-invalid");

        $(this)
            .siblings(".error-message")
            .text("");

    });

});











// ================= DATE & TIME =================

function updateDateTime() {

    const now = new Date();

    const dateOptions = {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric"
    };

    const currentDate = now.toLocaleDateString(
        "en-BD",
        dateOptions
    );

    const currentTime = now.toLocaleTimeString(
        "en-BD",
        {
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit"
        }
    );


    const dateElement =
        document.getElementById("currentDate");

    if (dateElement) {
        dateElement.innerText = currentDate;
    }


    const timeElement =
        document.getElementById("currentTime");

    if (timeElement) {
        timeElement.innerText = currentTime;
    }

}


updateDateTime();

setInterval(updateDateTime, 1000);


// ================= JQUERY =================

$(document).ready(function () {


    // ================= PASSWORD SHOW / HIDE =================

    $("#togglePassword").click(function () {

        const passwordInput = $("#loginPassword");

        const icon = $(this).find("i");


        if (passwordInput.attr("type") === "password") {

            passwordInput.attr("type", "text");

            icon.removeClass("fa-eye");
            icon.addClass("fa-eye-slash");

        } else {

            passwordInput.attr("type", "password");

            icon.removeClass("fa-eye-slash");
            icon.addClass("fa-eye");

        }

    });


    // ================= LOGIN FORM =================

    $("#loginForm").submit(function (e) {

        e.preventDefault();


        // Clear old errors

        $("#nameError").text("");
        $("#passwordError").text("");

        $("#loginName").removeClass("is-invalid");
        $("#loginPassword").removeClass("is-invalid");


        // Get values

        const name = $("#loginName").val().trim();

        const password = $("#loginPassword").val().trim();


        let isValid = true;


        // ================= NAME VALIDATION =================

        if (name === "") {

            $("#nameError").text(
                "Please enter your name."
            );

            $("#loginName").addClass("is-invalid");

            isValid = false;

        }


        // ================= PASSWORD VALIDATION =================

        if (password === "") {

            $("#passwordError").text(
                "Please enter your password."
            );

            $("#loginPassword").addClass("is-invalid");

            isValid = false;

        }

        else if (password.length < 6) {

            $("#passwordError").text(
                "Password must contain at least 6 characters."
            );

            $("#loginPassword").addClass("is-invalid");

            isValid = false;

        }


        // ================= CONFIRMATION POPUP =================

        if (isValid) {

            const confirmation = confirm(
                "Hello " +
                name +
                "!\n\n" +
                "Are you sure you want to login?"
            );


            if (confirmation) {

                alert(
                    "Login successful!\n\n" +
                    "Welcome to News Portal."
                );

                // Demo purpose
                // Real website হলে এখানে dashboard page দেওয়া যাবে।

            } else {

                alert(
                    "Login cancelled."
                );

            }

        }

    });


    // ================= REMOVE ERROR =================

    $("#loginName").on("input", function () {

        $(this).removeClass("is-invalid");

        $("#nameError").text("");

    });


    $("#loginPassword").on("input", function () {

        $(this).removeClass("is-invalid");

        $("#passwordError").text("");

    });


    // ================= FORGOT PASSWORD =================

    $(".forgot-password").click(function (e) {

        e.preventDefault();

        alert(
            "Please contact the administrator to reset your password."
        );

    });

});